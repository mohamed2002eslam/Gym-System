import java.util.Scanner;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JPanel;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.sql.Date;
import java.util.ArrayList;
public class Main {
	

	public static void main(String[] args) {
		
		
		
		
		Choose c=new Choose();
		Health_Club h = new Health_Club();
		
		c.Health_Club(h);
		c.setVisible(true);
		/////////////////////////
		 
	}

}
