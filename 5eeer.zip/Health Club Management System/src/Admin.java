import java.util.List;
import java.util.ArrayList;
class Admin extends User {
	private ArrayList<Coach> coaches = new ArrayList<Coach>();
    private ArrayList<Member> members = new ArrayList<Member>();
 

    
    public Admin(String username, String password) {
		super(username, password);
		
	}




	public void addCoach(Coach coach) {
        coaches.add(coach);
        
    }

    public void removeCoach(Coach coach) {
        coaches.remove(coach);
    }
    
   /* public void updateCoach(Coach coach) {
    	int index = coaches.indexOf(coach);
        coaches.set(index, coach);
    } 
    public List<Coach> getCoaches() {
        return coaches;
    }
    public void listCoaches() {
        for (Coach coach : coaches) {
            System.out.println(coach.getUsername());
        }
    }

    public String searchCoach(String username) {
    	for (Coach coach : coaches) {
            if (coach.getUsername().equals(username)) {
                return  coach.getUsername();
            }
        }
        return null;
    }

    */

    public void addMember(Member member) {
        members.add(member);
    }

    public void removeMember(Member member) {
        members.remove(member);
    }
   /* public void updateMember(Member member) {
    	int index = members.indexOf(member);
        members.set(index, member);
    }
    public List<Member> getMembers() {
        return members;
    }
    public void listMembers() {
        for (Member member : members) {
            System.out.println(member.getUsername());
        }
    }
    public String searchMembers(String username) {
    	for (Member member : members) {
            if (member.getUsername().equals(username)) {
                return member.getUsername();
            }
        }
        return null;
    }
    */
	public void setBilling(Member member) {
		
		
		if(member.getBilling().equals("400"))
		{
			 member.setDays("30");
		}
		else if(member.getBilling().equals("600"))
		{
			member.setDays("90");		}
		else if(member.getBilling().equals("1000"))
		{
			member.setDays("180");		}
		else if(member.getBilling().equals("1400"))
		{
			member.setDays("365");		}
		
		else
		{
			System.out.println("Error");
		}
	}


	public  String makeReport(Member member) {
        return member.toString();
    	
    }

    

	public void assignCoach(Member member, Coach coach) {
        member.setCoach(coach);
        coach.addMember(member);
    }

    public String sendNotification(Member member) {
        

		return " [Days left=" + member.getDays() + "]";
    }


	
}
