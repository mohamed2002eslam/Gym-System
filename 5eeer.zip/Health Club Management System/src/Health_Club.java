import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import javax.swing.JOptionPane;

public class Health_Club {

	int id = 0;
	static int count = 0;

	final String pin = "dababy";
	Admin admin1 = new Admin("mo", "islam");
	Coach c1 = new Coach("mayar", "abd");
	ArrayList<Admin> admins = new ArrayList<Admin>(Arrays.asList(admin1));
	ArrayList<Member> members = new ArrayList<Member>();
	ArrayList<Coach> coachs = new ArrayList<Coach>(Arrays.asList(c1));

	String D1 = "Tuesday, Wednesday, Friday, Saturday";
	String D2 = "Saturday, Tuesday, Wednesday, Saturday";
	String D3 = "Monday, Wednesday, Friday, Saturday";

	String P1 = "Keto";
	String P2 = "MOMN";
	String P3 = "arnold";

	public Health_Club() {
		Buffer();
	}

	public void Buffer() {
		BufferedReader reader;
		String id = null;
		String user = null;
		String pass = null;
		String bill = null;

		try {
			reader = new BufferedReader(new FileReader("Member.txt"));
			String line = reader.readLine();

			while (line != null) {

				String[] ss = line.split("\t");

				user = ss[1];
				pass = ss[2];
				bill = ss[3];

				// read next line

				Member member = new Member(user, pass, bill);
				admin1.addMember(member);
				members.add(member);
				line = reader.readLine();

			}
			reader.close();
		} catch (IOException e) {
			JOptionPane.showMessageDialog(null, "error\n");
		}

	}

	public boolean LoginAdmin(String em1, String pal) {
		boolean found = false;
		for (int i = 0; i < admins.size(); i++) {
			if (em1.equals(admins.get(i).getUsername()) && pal.equals(admins.get(i).getPassword()))
				found = true;

		}
		return found;
	}

	public boolean getpin(String pinc) {
		boolean found = false;
		if (pin.equals(pinc)) {
			found = true;
		}
		return found;
	}

	public boolean LoginMember(String em1, String pal) {
		boolean found = false;
		for (int i = 0; i < members.size(); i++) {
			if (em1.equals(members.get(i).getUsername()) && pal.equals(members.get(i).getPassword())) {

				found = true;

			}
		}
		return found;
	}

	public void Register(String email, String pass) {
		try {
			BufferedWriter bw = new BufferedWriter(new FileWriter("Admin.txt", true));
			bw.write(String.format("%s\t%s", email, pass));
			bw.newLine();
			bw.close();
		} catch (IOException ex) {
			JOptionPane.showMessageDialog(null, "Error writing to file!", "Error", JOptionPane.ERROR_MESSAGE);
		}
		Admin m1 = new Admin(email, pass);
		admins.add(m1);
	}

	public void addC(String email, String pass) {
		Coach c1 = new Coach(email, pass);
		admin1.addCoach(c1);
		coachs.add(c1);
		JOptionPane.showMessageDialog(null, "New Coach Added");

	}

	public boolean LoginCoach(String em1, String pal) {
		boolean found = false;
		for (int i = 0; i < coachs.size(); i++) {
			if (em1.equals(coachs.get(i).getUsername()) && pal.equals(coachs.get(i).getPassword())) {

				found = true;
			}
		}
		return found;
	}

	public void addM(String email, String pass, String bill) {
		Member x1 = new Member(email, pass, bill);
		admin1.addMember(x1);
		members.add(x1);

		try {
			PrintWriter pw = new PrintWriter("Member.txt");
			pw.write("");
			pw.close();
			BufferedWriter bw = new BufferedWriter(new FileWriter("Member.txt", true));
			for (int i = 0; i < members.size(); i++) {
				Member member = members.get(i);
				bw.write(String.format("%s\t%s\t%s\t%s", member.getId(), member.getUsername(), member.getPassword(),
						member.getBilling()));
				bw.newLine();

			}
			bw.close();
		} catch (IOException ex) {
			JOptionPane.showMessageDialog(null, "Error writing to file!", "Error", JOptionPane.ERROR_MESSAGE);
		}
		JOptionPane.showMessageDialog(null, "New Member Added");
	}

	public void GetM(int id) {
		int i;
		boolean f = false;
		for (i = 0; i < members.size(); i++) {

			if (id == members.get(i).getId()) {

				JOptionPane.showMessageDialog(null, members.get(i).getUsername() + "\n");

				f = true;
			}

		}
		if (f != true) {
			JOptionPane.showMessageDialog(null, "error\n");
			// System.out.print("error\n");
		}

	}

	public void Report(int id) {
		int i;
		boolean f = false;
		for (i = 0; i < members.size(); i++) {

			if (id == members.get(i).getId()) {
				String bill = members.get(i).getBilling();
				members.get(i).setBilling(bill);

				admin1.setBilling(members.get(i));

				JOptionPane.showMessageDialog(null, members.get(i).toString() + "\n");

				f = true;
			}

		}
		if (f != true) {
			JOptionPane.showMessageDialog(null, "error\n");
			// System.out.print("error\n");
		}
	}

	public boolean DeleteM(int id) {
		int i;
		boolean f = false;
		for (i = 0; i < members.size(); i++) {

			if (id == members.get(i).getId()) {

				members.remove(i);
				f = true;
			}

		}
		return f;
	}

	public void GetC(String name) {
		int i;
		boolean f = false;
		for (i = 0; i < coachs.size(); i++) {

			if (name.equals(coachs.get(i).getUsername())) {

				JOptionPane.showMessageDialog(null, coachs.get(i).getUsername() + "\n");
				f = true;
			}

		}
		if (f != true) {
			JOptionPane.showMessageDialog(null, "Not Found\n");
			// System.out.print("error\n");
		}

	}

	public boolean DeleteC(String name) {
		int i;
		boolean f = false;
		for (i = 0; i < coachs.size(); i++) {

			if (name.equals(coachs.get(i).getUsername())) {

				coachs.remove(i);
				f = true;
			}

		}
		return f;
	}

	public void getcoach(int id) {
		int i;
		boolean f = false;

		for (i = 0; i < members.size(); i++) {

			if (id == members.get(i).getId()) {

				Coach coach = members.get(i).getCoach();
				JOptionPane.showMessageDialog(null, coach.getUsername());
				f = true;
			}

		}
		if (f != true) {
			JOptionPane.showMessageDialog(null, "error\n");
			// System.out.print("error\n");
		}

	}

	public void AssignCM(int id, String name) {
		int i;
		boolean f = false;
		for (i = 0; i < members.size(); i++) {

			if (id == members.get(i).getId()) {
				f = true;
				int j;
				boolean t = false;
				for (j = 0; j < coachs.size(); j++) {

					if (name.equals(coachs.get(j).getUsername())) {

						admin1.assignCoach(members.get(i), coachs.get(j));
						JOptionPane.showMessageDialog(null, "Done\n");
						t = true;
					}

				}
				if (t != true) {
					JOptionPane.showMessageDialog(null, "error\n");
					// System.out.print("error\n");
				}

			}

		}
		if (f != true) {
			JOptionPane.showMessageDialog(null, "error\n");
			// System.out.print("error\n");
		}

	}

	public void getPlan(int id) {
		int i;
		boolean f = false;

		for (i = 0; i < members.size(); i++) {

			if (id == members.get(i).getId()) {

				JOptionPane.showMessageDialog(null, members.get(i).getPlan());
				f = true;
			}

		}
		if (f != true) {
			JOptionPane.showMessageDialog(null, "error\n");
			// System.out.print("error\n");
		}
	}

	public void getSchedule(int id) {
		int i;
		boolean f = false;

		for (i = 0; i < members.size(); i++) {

			if (id == members.get(i).getId()) {

				JOptionPane.showMessageDialog(null, members.get(i).getSchedule());
				f = true;
			}

		}
		if (f != true) {
			JOptionPane.showMessageDialog(null, "error\n");
		}
	}

	public void Notification(String em1, String pal) {
		boolean f = false;
		for (int i = 0; i < members.size(); i++) {
			if (em1.equals(members.get(i).getUsername()) && pal.equals(members.get(i).getPassword())) {
				String bill = members.get(i).getBilling();
				members.get(i).setBilling(bill);

				admin1.setBilling(members.get(i));

				JOptionPane.showMessageDialog(null, members.get(i).getDays() + " days left");
				f = true;

			}

		}
		if (f != true) {
			JOptionPane.showMessageDialog(null, "error\n");
		}

	}

	public void Schedule_Plan(int id, String schedule, String plan) {
		int i;
		boolean f = false;
		for (i = 0; i < members.size(); i++) {

			if (id == members.get(i).getId()) {
				f = true;
				if (schedule.equals("D1"))
					schedule = D1;
				else if (schedule.equals("D2"))
					schedule = D2;
				else if (schedule.equals("D3"))
					schedule = D3;
				else
					f = false;
				if (plan.equals("P1"))
					plan = P1;
				else if (plan.equals("P2"))
					plan = P2;
				else if (plan.equals("P3"))
					plan = P3;
				else
					f = false;
				members.get(i).setSchedule(schedule);
				members.get(i).setPlan(plan);
			}
		}
		if (f == true)
			JOptionPane.showMessageDialog(null, "Done\n");
		else if (f != true) {
			JOptionPane.showMessageDialog(null, "error\n");
			// System.out.print("error\n");
		}

	}

	public void sendMessage(int id, String message) {

		int i;
		boolean f = false;

		for (i = 0; i < members.size(); i++) {

			if (id == members.get(i).getId()) {

				members.get(i).setMessage(message);
				JOptionPane.showMessageDialog(null, "Done\n");
				f = true;
			}

		}
		if (f != true) {
			JOptionPane.showMessageDialog(null, "error\n");
		}

	}

	public void getMessage(int id) {
		int i;
		boolean f = false;

		for (i = 0; i < members.size(); i++) {

			if (id == members.get(i).getId()) {

				JOptionPane.showMessageDialog(null, members.get(i).getMessage());
				f = true;
			}

		}
		if (f != true) {
			JOptionPane.showMessageDialog(null, "error\n");
		}
	}

	public void getsubend(int id) {
		int i;
		boolean f = false;

		for (i = 0; i < members.size(); i++) {

			if (id == members.get(i).getId()) {

				JOptionPane.showMessageDialog(null, members.get(i).getDays() + " days left");
				f = true;
			}

		}
		if (f != true) {
			JOptionPane.showMessageDialog(null, "error\n");
		}
	}

	public void list_Member() {
		String m = "";
		for (int i = 0; i < members.size(); i++) {
			m += "Name: " + members.get(i).getUsername() + "\t \tID: " + members.get(i).getId() + "\n";
		}
		JOptionPane.showMessageDialog(null, m);
	}

	public void list_Coach() {
		String m = "";
		for (int i = 0; i < coachs.size(); i++) {
			m += "Name: " + coachs.get(i).getUsername() + "\t \tPassword: " + coachs.get(i).getPassword() + "\n";
		}
		JOptionPane.showMessageDialog(null, m);
	}

	public void currentuser(String name, String pass) {
		for (int i = 0; i < members.size(); i++) {
			if (name.equals(members.get(i).getUsername()) && pass.equals(members.get(i).getPassword())) {

				id = members.get(i).getId();

			}
		}

	}

	public int getuser() {
		return id;
	}

	public void updatem(int id, String name, String pass, String bill) {
		int i;
		boolean f = false;

		for (i = 0; i < members.size(); i++) {

			if (id == members.get(i).getId()) {

				members.get(i).setUsername(name);
				members.get(i).setPassword(pass);
				JOptionPane.showMessageDialog(null, "done");
				f = true;
			}

		}
		if (f != true) {
			JOptionPane.showMessageDialog(null, "error\n");
		}
	}

	public void updatec(String oname, String opass, String nname, String npass) {
		int j;
		boolean t = false;
		for (j = 0; j < coachs.size(); j++) {

			if (oname.equals(coachs.get(j).getUsername())) {

				coachs.get(j).setUsername(nname);
				coachs.get(j).setPassword(npass);
				JOptionPane.showMessageDialog(null, "Done\n");
				t = true;
			}

		}
		if (t != true) {
			JOptionPane.showMessageDialog(null, "error\n");
			// System.out.print("error\n");
		}

	}

}