import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;

public class upm extends JFrame {

	private JPanel contentPane;
	private JTextField IdField;
	private JTextField nameField;
	private JTextField passField;
	private JTextField billField;
	Health_Club healthclub;
	private JButton btnNewButton_1;
	private JLabel lblNewLabel;
	private JLabel lblNewLabel_1;
	private JLabel lblNewLabel_2;
	private JLabel lblNewLabel_3;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					upm frame = new upm();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public void Health_Club(Health_Club healthclub)
	{
		this.healthclub=healthclub;
	}
	public upm() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 691, 409);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		IdField = new JTextField();
		IdField.setBounds(274, 83, 96, 19);
		contentPane.add(IdField);
		IdField.setColumns(10);
		
		nameField = new JTextField();
		nameField.setText("");
		nameField.setBounds(274, 172, 96, 19);
		contentPane.add(nameField);
		nameField.setColumns(10);
		
		passField = new JTextField();
		passField.setBounds(274, 233, 96, 19);
		contentPane.add(passField);
		passField.setColumns(10);
		
		billField = new JTextField();
		billField.setBounds(274, 287, 96, 19);
		contentPane.add(billField);
		billField.setColumns(10);
		
		JButton btnNewButton = new JButton("New button");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String id= IdField.getText();
				String name= nameField.getText();
				String pass=passField.getText();
				String bill=billField.getText();
				int i=Integer.parseInt(id);
				healthclub.updatem(i, name, pass, bill);

			}
		});
		btnNewButton.setBounds(285, 341, 85, 21);
		contentPane.add(btnNewButton);
		
		btnNewButton_1 = new JButton("back");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				menu c= new menu();
				c.setVisible(true);
				c.Health_Club(healthclub);
				dispose();
			}
		});
		btnNewButton_1.setBounds(555, 351, 85, 21);
		contentPane.add(btnNewButton_1);
		
		lblNewLabel = new JLabel("member's ID");
		lblNewLabel.setBounds(285, 58, 107, 21);
		contentPane.add(lblNewLabel);
		
		lblNewLabel_1 = new JLabel("Name");
		lblNewLabel_1.setBounds(174, 175, 45, 13);
		contentPane.add(lblNewLabel_1);
		
		lblNewLabel_2 = new JLabel("Pass");
		lblNewLabel_2.setBounds(174, 236, 45, 13);
		contentPane.add(lblNewLabel_2);
		
		lblNewLabel_3 = new JLabel("bill");
		lblNewLabel_3.setBounds(174, 293, 45, 13);
		contentPane.add(lblNewLabel_3);
	}
}
