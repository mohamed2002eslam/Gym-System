import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Window.Type;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JPasswordField;
import java.awt.Color;
import javax.swing.ImageIcon;
import java.awt.Font;

public class MainFrame_Login extends JFrame {

	private JPanel contentPane;
	private JTextField tfName;
	private JPasswordField passwordField;

	/**
	 * Launch the application.
	 */
	Health_Club healthclub;
	private JTextField pin_code;
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainFrame_Login frame = new MainFrame_Login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public void Health_Club(Health_Club healthclub)
	{
		this.healthclub=healthclub;
	}
	public MainFrame_Login() {
		setTitle("Welcome");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 762, 508);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(32, 32, 32));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Name");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel.setForeground(Color.LIGHT_GRAY);
		lblNewLabel.setBounds(346, 209, 69, 30);
		contentPane.add(lblNewLabel);
		
		tfName = new JTextField();
		tfName.setBounds(251, 249, 237, 19);
		contentPane.add(tfName);
		tfName.setColumns(10);
		
		JLabel lblWelcome = new JLabel("");
		lblWelcome.setBounds(13, 165, 135, 13);
		contentPane.add(lblWelcome);
		
		JButton btnlogin = new JButton("login");
		btnlogin.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 12));
		btnlogin.setBackground(Color.YELLOW);
		btnlogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String Username= tfName.getText();
				String PassWord= passwordField.getText();
				
				if(healthclub.LoginAdmin(Username, PassWord)==true)
				{
					menu m= new menu();
					
					m.setVisible(true);
				      m.Health_Club(healthclub);
				      dispose();
				      }
				      else
				           JOptionPane.showMessageDialog(null,"wrong username/password");
				      
				
			}
		});
		btnlogin.setBounds(330, 332, 85, 21);
		contentPane.add(btnlogin);
		
		JButton btnNewButton = new JButton("Sign up");
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 12));
		btnNewButton.setBackground(Color.YELLOW);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String pin = pin_code.getText();
				if(healthclub.getpin(pin)==true) {
				admin_sign m = new admin_sign();
				m.setVisible(true);
			      m.Health_Club(healthclub);
			      dispose();
				}
				else
					JOptionPane.showMessageDialog(null,"wrong Pin Code");
				
			}
		});
		btnNewButton.setBounds(330, 413, 85, 21);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Back");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Choose c= new Choose();
				c.setVisible(true);
				c.Health_Club(healthclub);
				dispose();
				
			}
		});
		btnNewButton_1.setBounds(631, 426, 107, 21);
		contentPane.add(btnNewButton_1);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(251, 303, 237, 19);
		contentPane.add(passwordField);
		
		JLabel lblNewLabel_1 = new JLabel("Password");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel_1.setForeground(Color.LIGHT_GRAY);
		lblNewLabel_1.setBounds(330, 278, 101, 19);
		contentPane.add(lblNewLabel_1);
		
		pin_code = new JTextField();
		pin_code.setBounds(251, 376, 237, 19);
		contentPane.add(pin_code);
		pin_code.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.setIcon(new ImageIcon("D:\\OneDrive\\Pictures\\Home (1).png"));
		lblNewLabel_3.setBounds(0, 0, 762, 507);
		contentPane.add(lblNewLabel_3);
	}
}
