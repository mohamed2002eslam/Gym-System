import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Font;

public class menu extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	Health_Club healthclub;
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					menu frame = new menu();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public void Health_Club(Health_Club healthclub)
	{
		this.healthclub=healthclub;
	}
	public menu() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 682, 498);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		
		JButton btnNewButton = new JButton("Logout");
		btnNewButton.setBounds(569, 430, 99, 21);
		btnNewButton.setBackground(new Color(240, 240, 240));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Choose c= new Choose();
				c.setVisible(true);
				c.Health_Club(healthclub);
				dispose();
			}
		});
		contentPane.setLayout(null);
		
		JButton btnNewButton_2 = new JButton("Update");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				upm m= new upm();
				
				m.Health_Club(healthclub);
				m.setVisible(true);
			      dispose();
			}
		});
		
		JButton btnNewButton_3 = new JButton("Update");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
                upc m= new upc();
				
				m.Health_Club(healthclub);
				m.setVisible(true);
			      dispose();
			}
		});
		btnNewButton_3.setBounds(426, 329, 85, 21);
		contentPane.add(btnNewButton_3);
		btnNewButton_2.setBounds(130, 329, 85, 21);
		contentPane.add(btnNewButton_2);
		contentPane.add(btnNewButton);
		
		JButton ADDM = new JButton("ADD");
		ADDM.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
                New_member m= new New_member();
				
				m.Health_Club(healthclub);
				m.setVisible(true);
			      dispose();
				
			}
		});
		ADDM.setBounds(130, 137, 85, 21);
		contentPane.add(ADDM);
		
		JButton SearchM = new JButton("Search");
		SearchM.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SeachMember s= new SeachMember();
				s.Health_Club(healthclub);
				s.setVisible(true);
				dispose();
				
				
				
			}
		});
		SearchM.setBounds(130, 238, 85, 21);
		contentPane.add(SearchM);
		
		JLabel lblNewLabel = new JLabel("Member");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel.setBounds(147, 90, 85, 37);
		contentPane.add(lblNewLabel);
		
		JButton DeleteM = new JButton("Delete");
		DeleteM.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Delete_member m= new Delete_member();
				m.Health_Club(healthclub);
				m.setVisible(true);
				dispose();
				
			}
		});
		DeleteM.setBounds(130, 192, 85, 21);
		contentPane.add(DeleteM);
		
		JLabel lblNewLabel_1 = new JLabel("Coach");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel_1.setBounds(447, 77, 73, 62);
		contentPane.add(lblNewLabel_1);
		
		JButton ADDC = new JButton("ADD");
		ADDC.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ADD_Coach m= new ADD_Coach();
				m.Health_Club(healthclub);
				m.setVisible(true);
				dispose();
				
			}
		});
		ADDC.setBounds(426, 137, 85, 21);
		contentPane.add(ADDC);
		
		JButton SearchC = new JButton("Search");
		SearchC.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SearchCoach m= new SearchCoach();
				m.Health_Club(healthclub);
				m.setVisible(true);
				dispose();
			}
		});
		SearchC.setBounds(426, 238, 85, 21);
		contentPane.add(SearchC);
		
		JButton DeleteC = new JButton("Delete");
		DeleteC.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Delete_Coach m= new Delete_Coach();
				m.Health_Club(healthclub);
				m.setVisible(true);
				dispose();
				
			}
		});
		DeleteC.setBounds(426, 192, 85, 21);
		contentPane.add(DeleteC);
		
		JButton btnNewButton_1 = new JButton("Assign");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				assign a= new assign ();
				a.Health_Club(healthclub);
				a.setVisible(true);
				dispose();
			}
		});
		btnNewButton_1.setBounds(295, 384, 85, 21);
		contentPane.add(btnNewButton_1);
		
		JButton List_member = new JButton("List");
		List_member.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				healthclub.list_Member();
				
			}
		});
		List_member.setBounds(130, 281, 85, 21);
		contentPane.add(List_member);
		
		JButton List_coach = new JButton("List");
		List_coach.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				healthclub.list_Coach();
			}
		});
		List_coach.setBounds(426, 281, 85, 21);
		contentPane.add(List_coach);
		
		JLabel lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setIcon(new ImageIcon("D:\\OneDrive\\Pictures\\Blank 2 Panel Portraits Comic Strip (1).png"));
		lblNewLabel_2.setBounds(0, 0, 682, 500);
		contentPane.add(lblNewLabel_2);
	}
}
