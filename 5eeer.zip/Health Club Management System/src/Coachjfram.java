import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JInternalFrame;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JPasswordField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import java.awt.Font;

public class Coachjfram extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JPasswordField passwordField;

	/**
	 * Launch the application.
	 */
	Health_Club healthclub;
	private JButton btnNewButton_1;
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Coachjfram frame = new Coachjfram();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public void Health_Club(Health_Club healthclub)
	{
		this.healthclub=healthclub;
	}
	public Coachjfram() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 610, 408);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel_3 = new JLabel("Password");
		lblNewLabel_3.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 12));
		lblNewLabel_3.setBounds(141, 188, 71, 13);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_2 = new JLabel("Username");
		lblNewLabel_2.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 12));
		lblNewLabel_2.setBounds(141, 121, 71, 21);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel = new JLabel("Welcome Coach");
		lblNewLabel.setBounds(215, 56, 153, 18);
		contentPane.add(lblNewLabel);
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 15));
		
		JPanel panel = new JPanel();
		panel.setBounds(215, 53, 113, 21);
		contentPane.add(panel);
		panel.setLayout(null);
		
		textField = new JTextField();
		textField.setBounds(107, 147, 121, 19);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JButton btnNewButton = new JButton("Login");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String Username= textField.getText();
				String PassWord= passwordField.getText();
				
				if(healthclub.LoginCoach(Username, PassWord)==true)
				{
					Coach_window  m= new Coach_window ();
					
					m.setVisible(true);
				      m.Health_Club(healthclub);
				      dispose();
				      }
				      else
				           JOptionPane.showMessageDialog(null,"wrong username/password");
				      
				
			}
			
		});
		btnNewButton.setBounds(127, 256, 85, 21);
		contentPane.add(btnNewButton);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(107, 211, 121, 19);
		contentPane.add(passwordField);
		
		btnNewButton_1 = new JButton("Back");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Choose c= new Choose();
				c.setVisible(true);
				c.Health_Club(healthclub);
				dispose();
			}
		});
		btnNewButton_1.setBounds(501, 340, 85, 21);
		contentPane.add(btnNewButton_1);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon("D:\\OneDrive\\Pictures\\coach.jpg"));
		lblNewLabel_1.setBounds(0, 0, 606, 371);
		contentPane.add(lblNewLabel_1);
	}
}
