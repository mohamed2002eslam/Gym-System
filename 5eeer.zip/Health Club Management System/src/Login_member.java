import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import java.awt.Toolkit;
import java.awt.Color;
import java.awt.Font;
import javax.swing.SwingConstants;

public class Login_member extends JFrame {

	private JPanel contentPane;
	

	/**
	 * Launch the application.
	 */
	Health_Club healthclub;
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login_member frame = new Login_member();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public void Health_Club(Health_Club healthclub)
	{
		this.healthclub=healthclub;
	}
	public Login_member() {
		setIconImage(Toolkit.getDefaultToolkit().getImage("D:\\OneDrive\\Pictures\\Screenshot 2023-05-29 221712.png"));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1000, 575);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnNewButton = new JButton("Log out");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Choose c= new Choose();
				c.setVisible(true);
				c.Health_Club(healthclub);
				dispose();
			}
		});
		
		JButton btnNewButton_6 = new JButton("ID");
		btnNewButton_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				JOptionPane.showMessageDialog(null,healthclub.getuser());
				
			}
		});
		btnNewButton_6.setBounds(104, 229, 106, 21);
		contentPane.add(btnNewButton_6);
		
		JLabel lblNewLabel = new JLabel("Member's ID");
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 14));
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setBounds(117, 181, 127, 31);
		contentPane.add(lblNewLabel);
		btnNewButton.setBounds(10, 507, 85, 21);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Coach");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				healthclub.getcoach(healthclub.getuser());
				
				
			}
		});
		btnNewButton_1.setBounds(455, 421, 81, 21);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Plan");
		btnNewButton_2.setForeground(new Color(0, 139, 139));
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				healthclub.getPlan(healthclub.getuser());
				
			}
		});
		btnNewButton_2.setBounds(451, 163, 85, 21);
		contentPane.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("Schedule");
		btnNewButton_3.setFont(new Font("Tahoma", Font.BOLD, 9));
		btnNewButton_3.setForeground(new Color(0, 139, 139));
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				healthclub.getSchedule(healthclub.getuser());
				
				
			}
		});
		btnNewButton_3.setBounds(451, 213, 85, 21);
		contentPane.add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("Message");
		btnNewButton_4.setFont(new Font("Tahoma", Font.BOLD, 9));
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				healthclub.getMessage(healthclub.getuser());
			}
		});
		btnNewButton_4.setBounds(455, 463, 82, 21);
		contentPane.add(btnNewButton_4);
		
		JButton btnNewButton_5 = new JButton("End of sub");
		btnNewButton_5.setFont(new Font("Tahoma", Font.BOLD, 9));
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				healthclub.getsubend(healthclub.getuser());
			}
		});
		btnNewButton_5.setBounds(10, 476, 81, 21);
		contentPane.add(btnNewButton_5);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon("D:\\OneDrive\\Pictures\\Screenshot 2023-05-29 221712 (1).png"));
		lblNewLabel_1.setBounds(0, 0, 1000, 550);
		contentPane.add(lblNewLabel_1);
	}
}
