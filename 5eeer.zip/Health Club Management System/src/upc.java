import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class upc extends JFrame {

	private JPanel contentPane;
	private JTextField Oldname;
	private JTextField Oldpass;
	private JTextField Newname;
	private JTextField Newpass;
	Health_Club healthclub;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					upc frame = new upc();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public void Health_Club(Health_Club healthclub)
	{
		this.healthclub=healthclub;
	}
	public upc() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 546, 360);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		Oldname = new JTextField();
		Oldname.setBounds(75, 107, 96, 19);
		contentPane.add(Oldname);
		Oldname.setColumns(10);
		
		Oldpass = new JTextField();
		Oldpass.setBounds(75, 189, 96, 19);
		contentPane.add(Oldpass);
		Oldpass.setColumns(10);
		
		Newname = new JTextField();
		Newname.setColumns(10);
		Newname.setBounds(304, 107, 96, 19);
		contentPane.add(Newname);
		
		Newpass = new JTextField();
		Newpass.setColumns(10);
		Newpass.setBounds(304, 189, 96, 19);
		contentPane.add(Newpass);
		
		JButton btnNewButton = new JButton("Change");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String oldname=Oldname.getText();
				String oldpass=Oldpass.getText();
				String newname=Newname.getText();
				String newpass=Newpass.getText();
				
				healthclub.updatec(oldname, oldpass, newname, newpass);
				
			}
		});
		btnNewButton.setBounds(199, 259, 85, 21);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("back");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				menu c= new menu();
				c.setVisible(true);
				c.Health_Club(healthclub);
				dispose();
			}
		});
		btnNewButton_1.setBounds(437, 292, 85, 21);
		contentPane.add(btnNewButton_1);
		
		JLabel lblNewLabel = new JLabel("Name");
		lblNewLabel.setBounds(98, 82, 45, 13);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Pass");
		lblNewLabel_1.setBounds(98, 166, 45, 13);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Name");
		lblNewLabel_2.setBounds(326, 82, 45, 13);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Pass");
		lblNewLabel_3.setBounds(326, 166, 45, 13);
		contentPane.add(lblNewLabel_3);
	}

}
