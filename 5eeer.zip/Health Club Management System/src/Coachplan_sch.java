import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JTable;
import java.awt.ScrollPane;
import java.awt.Choice;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.JList;

public class Coachplan_sch extends JFrame {

	private JPanel contentPane;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	
	Health_Club healthclub;
	private JLabel lblNewLabel;
	private JLabel lblNewLabel_1;
	private JLabel lblNewLabel_2;
	private JLabel lblNewLabel_3;
	JComboBox<Object> comboBox;
	JComboBox<Object> comboBox_1;
	private JPanel panel;
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Coachplan_sch frame = new Coachplan_sch();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public void Health_Club(Health_Club healthclub)
	{
		this.healthclub=healthclub;
	}

	/**
	 * Create the frame.
	 */
	public Coachplan_sch() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 797, 529);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
        String[] Schedule= new String[]{"D1","D2","D3","D4"};
        String[] Plan= new String[]{"P1","P2","P3","P4"};
		comboBox_1= new JComboBox<Object>(Plan);
	
		comboBox_1.setBounds(172, 255, 123, 21);
		contentPane.add(comboBox_1);
		
		comboBox= new JComboBox<Object>(Schedule);
		
		
		comboBox.setBounds(172, 358, 123, 19);
		contentPane.add(comboBox);
		
		textField = new JTextField();
		textField.setBounds(172, 152, 123, 19);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("Member's ID");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel.setBounds(194, 113, 101, 28);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("plan");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_1.setBounds(213, 220, 55, 21);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Schedule");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_2.setBounds(194, 317, 82, 21);
		contentPane.add(lblNewLabel_2);
		
		JButton btnNewButton = new JButton("Back");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Coach_window  m= new Coach_window ();
				
				m.setVisible(true);
			      m.Health_Club(healthclub);
			      dispose();
				
			}
		});
		btnNewButton.setBounds(688, 450, 85, 21);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Add");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String id= textField.getText();
				String schedule = (String) comboBox.getSelectedItem();
				String plan = (String) comboBox_1.getSelectedItem();
				int idm=Integer.parseInt(id);
				
				healthclub.Schedule_Plan(idm, schedule, plan);
				
				
			}
		});
		btnNewButton_1.setBounds(194, 405, 85, 21);
		contentPane.add(btnNewButton_1);
		
		JLabel lblNewLabel_3 = new JLabel("\r\n");
		lblNewLabel_3.setIcon(new ImageIcon("D:\\OneDrive\\Pictures\\workout-plan-background-dumbbells-wooden-gym-floor-table-fitness-training-personal-trainer-old-iron-exercise-weights-84156254.jpg"));
		lblNewLabel_3.setBounds(-11, 0, 804, 530);
		contentPane.add(lblNewLabel_3);
	}
}