import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.JLabel;
import java.awt.Toolkit;
import javax.swing.ImageIcon;
import java.awt.Color;
import java.awt.Font;

public class Coach_window extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	Health_Club healthclub;
	private JTextField textField;
	private JTextField Id;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Coach_window frame = new Coach_window();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public void Health_Club(Health_Club healthclub)
	{
		this.healthclub=healthclub;
	}
	public Coach_window() {
		setIconImage(Toolkit.getDefaultToolkit().getImage("D:\\OneDrive\\Pictures\\heeer.png"));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 998, 662);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnNewButton = new JButton("Logout");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Choose c= new Choose();
				c.setVisible(true);
				c.Health_Club(healthclub);
				dispose();
			}
		});
		btnNewButton.setBounds(824, 547, 130, 33);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Send");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String id= Id.getText();
				int i=Integer.parseInt(id);
				String message =textField.getText();
				
				healthclub.sendMessage(i, message);
				
			}
		});
		btnNewButton_1.setBounds(663, 314, 85, 21);
		contentPane.add(btnNewButton_1);
		
		textField = new JTextField();
		textField.setBounds(588, 267, 245, 19);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JButton btnNewButton_2 = new JButton("GO");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Coachplan_sch c= new Coachplan_sch();
				c.setVisible(true);
				c.Health_Club(healthclub);
				dispose();
				
			}
		});
		btnNewButton_2.setBounds(37, 83, 85, 21);
		contentPane.add(btnNewButton_2);
		
		JLabel lblNewLabel = new JLabel("Plan & schedule");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setBounds(27, 24, 111, 46);
		contentPane.add(lblNewLabel);
		
		Id = new JTextField();
		Id.setBounds(652, 191, 96, 19);
		contentPane.add(Id);
		Id.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Send message");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_1.setForeground(Color.WHITE);
		lblNewLabel_1.setBounds(663, 236, 102, 21);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Member ID's");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_2.setForeground(Color.WHITE);
		lblNewLabel_2.setBounds(664, 155, 77, 26);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.setIcon(new ImageIcon("D:\\OneDrive\\Pictures\\heeer.png"));
		lblNewLabel_3.setBounds(0, 0, 1000, 667);
		contentPane.add(lblNewLabel_3);
	}
}
