import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

class Coach extends User {
	private ArrayList<Member> members;
    private String plan;
    public String schedule;
    

    public Coach(String username, String password) {
        super(username, password);
        members = new ArrayList<Member>();
    }
 
/*
    public List<Member> getMembers() {
        return members;
        
    }
*/
    public void addMember(Member member) {
        members.add(member);
    }

    public void removeMember(Member member) {
        members.remove(member);
    }
/*
    public String getPlan() {
        return plan;
    }

    public void setPlan(String plan) {
        this.plan = plan;
        
    }
    
*/
    public String getSchedule() {
        return schedule;
    }

    public void setSchedule(String schedule,Member mschedule) {
        this.schedule = schedule;
        for(int i=0;i<members.size();i++) {
        	if(members.get(i)==mschedule)
        	{
        		members.get(i).setSchedule(schedule);
        	}
        	else
        		System.out.print("ERROR");
        }
        
    }
/*
    public void sendMessage(Member member,String message) {
    	member.setMessage(message);
    	
    }
    */
}
