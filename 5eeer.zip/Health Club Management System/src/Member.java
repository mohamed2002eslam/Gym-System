
public class Member extends User{
	
	    int id=0;
	    static int count=0;
	    private Coach coach;
	    private String Days;
	    private String schedule;
	    private String billing;
	    private String plan;
	    private String message;
	    
	    
	    
	    public String getMessage() {
			return message;
		}


		public void setMessage(String message) {
			this.message = message;
		}


		public String getPlan() {
			return plan;
		}


		public void setPlan(String plan) {
			this.plan = plan;
		}


		public Member(String username, String password, String billing) {
			super(username, password);
			this.billing=billing;
			id=++count;
			
		}
	    


		public int getId() {
			return id;
		}


		public void setId(int id) {
			this.id = id;
		}


		public Coach getCoach() {
	        return coach;
	    }

	    public void setCoach(Coach coach) {
	        this.coach = coach;
	    }

	    public String getSchedule() {
			return schedule;
		}

		public void setSchedule(String schedule) {
			this.schedule = schedule;
		}
		public String getBilling() {
			return billing;
		}


		public void setBilling(String billing) {
			this.billing=billing;
			
		}
		public String getDays () {
			return Days ;
		}
		public void setDays (String i) {
			this.Days = i;
		}
		
		@Override
	    public String toString() {
	    	return "Member ID "+id+" \ncoach :" + coach.getUsername() + " \nschedule :" + schedule + " \nsubscriptionEndDate=" + Days + "\nPlan :"+plan+"";
	    }

		 public String getSubscriptionEndDate() {
		        return Days;
		    }


}
