import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JPasswordField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JComboBox;
import java.awt.Color;

public class New_member extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JPasswordField passwordField;

	Health_Club healthclub;
	private JLabel lblNewLabel;
	private JLabel lblNewLabel_1;
	private JLabel lblNewLabel_2;
	private JLabel lblNewLabel_3;
	JComboBox<Object> comboBox;
	private JPanel panel;
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					New_member frame = new New_member();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}


	public void Health_Club(Health_Club healthclub)
	{
		this.healthclub=healthclub;
	}
	public New_member() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		textField = new JTextField();
		textField.setBounds(168, 78, 96, 19);
		contentPane.add(textField);
		textField.setColumns(10);
		

		passwordField = new JPasswordField();
		passwordField.setBounds(168, 121, 96, 19);
		contentPane.add(passwordField);
		
		JButton btnNewButton = new JButton("Done");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String name= textField.getText();
				String pass= passwordField.getText();
				String bill= (String) comboBox.getSelectedItem();
				
				healthclub.addM(name, pass, bill);;
				
				
			}
		});
		btnNewButton.setBounds(180, 232, 85, 21);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Back");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				menu c= new menu();
				c.setVisible(true);
				c.Health_Club(healthclub);
				dispose();
			}
		});
		btnNewButton_1.setBounds(341, 232, 85, 21);
		contentPane.add(btnNewButton_1);
		
		lblNewLabel = new JLabel("Add Member");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel.setBounds(180, -1, 96, 42);
		contentPane.add(lblNewLabel);
		
		lblNewLabel_1 = new JLabel("Name");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_1.setBounds(93, 81, 52, 16);
		contentPane.add(lblNewLabel_1);
		
		lblNewLabel_2 = new JLabel("Password");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_2.setBounds(93, 124, 65, 16);
		contentPane.add(lblNewLabel_2);
		
		lblNewLabel_3 = new JLabel("Bill");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_3.setBounds(93, 176, 45, 13);
		contentPane.add(lblNewLabel_3);
		
		String[] bill= new String[]{"400","600","1000","1400"};
		
		comboBox= new JComboBox<Object>(bill);
		
		
		comboBox.setBounds(168, 173, 96, 21);
		contentPane.add(comboBox);
		
		panel = new JPanel();
		panel.setBounds(68, 51, 281, 170);
		contentPane.add(panel);
		
	}
}
