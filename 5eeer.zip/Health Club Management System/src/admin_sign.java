import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import java.awt.Color;

public class admin_sign extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JPasswordField passwordField;

	/**
	 * Launch the application.
	 */
	Health_Club healthclub;
	private JLabel lblNewLabel;
	private JLabel lblNewLabel_1;
	private JLabel lblNewLabel_2;
	private JPanel panel;
	private JButton btnNewButton_1;
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					admin_sign frame = new admin_sign();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public void Health_Club(Health_Club healthclub)
	{
		this.healthclub=healthclub;
	}

	/**
	 * Create the frame.
	 */
	public admin_sign() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 641, 415);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		textField = new JTextField();
		textField.setBounds(277, 117, 96, 19);
		contentPane.add(textField);
		textField.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(277, 166, 96, 19);
		contentPane.add(passwordField);
		
		JButton btnNewButton = new JButton("Sign up");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String email = textField.getText();
		        String Pass = passwordField.getText();
		        healthclub.Register(email, Pass);
		        
		        MainFrame_Login m = new MainFrame_Login();
		        m.setVisible(true);
		        m.Health_Club(healthclub);
		        dispose();
			}
		});
		btnNewButton.setBounds(289, 225, 85, 21);
		contentPane.add(btnNewButton);
		
		lblNewLabel = new JLabel("Name");
		lblNewLabel.setBounds(149, 120, 45, 13);
		contentPane.add(lblNewLabel);
		
		lblNewLabel_1 = new JLabel("Password\r\n");
		lblNewLabel_1.setBounds(149, 169, 120, 13);
		contentPane.add(lblNewLabel_1);
		
		lblNewLabel_2 = new JLabel("New Admin");
		lblNewLabel_2.setBounds(289, 61, 75, 13);
		contentPane.add(lblNewLabel_2);
		
		panel = new JPanel();
		panel.setBounds(112, 36, 398, 252);
		contentPane.add(panel);
		
		btnNewButton_1 = new JButton("Back");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MainFrame_Login c= new MainFrame_Login();
				c.setVisible(true);
				c.Health_Club(healthclub);
				dispose();
			}
		});
		btnNewButton_1.setBounds(532, 334, 85, 21);
		contentPane.add(btnNewButton_1);
	}

}
